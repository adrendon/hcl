import java.io.IOException;
import java.util.Scanner;

public class Main {
    static int numeroVentas = 0;
    static String[][] nombresGolosinas = {
            {"KitKat", "Chicles de fresa", "Lacasitos", "Palotes"},
            {"Kinder Bueno", "Bolsa variada Haribo", "Chetoos", "Twix"},
            {"Cheetos", "M&M'S", "Papa Delta", "Chicles de menta"},
            {"Lacasitos", "Crunch", "Milkybar", "KitKat"}
    };
    static double[][] precio = {
            {1.1, 0.8, 1.5, 0.9},
            {1.8, 1, 1.2, 1},
            {1.8, 1.3, 1.2, 0.8},
            {1.5, 1.1, 1.1, 1.1}
    };
    static int[][] cantidad = {
            {5, 5, 5, 5},
            {5, 5, 5, 5},
            {5, 5, 5, 5},
            {5, 5, 5, 5}
    };

    public static void main(String[] args) {
        System.out.println("Iniciando programa... \n");
        inicioProceso();
    }
    //Metodo que inicia el proceso
    public static void inicioProceso() {
        // Empezamos el recorrido
        String obtenerEntrada = "";
        do{
            System.out.println("Por favor introduzca la operación a realizar: ");
            System.out.println("1. Pedir golosina");
            System.out.println("2. Mostrar golosinas");
            System.out.println("3. Rellenar golosinas");
            System.out.println("4. Apagar maquina");

            //Realizamos objeto para obtener los datos por consola
            Scanner obtenerScanner = new Scanner(System.in); // Creamos el objeto scanner
            obtenerEntrada = obtenerScanner.nextLine();

            // Empezamos las condiciones
            if("1".equalsIgnoreCase(obtenerEntrada)){
                pedirGolosina();
                numeroVentas = numeroVentas + 1;
            }
            if("2".equalsIgnoreCase(obtenerEntrada)){
                mostrarGolosinas();
            }
            if("3".equalsIgnoreCase(obtenerEntrada)){
                rellenarInventario();
            }
            if("4".equalsIgnoreCase(obtenerEntrada)){
                System.out.println("Las ventas del día fueron: "+ numeroVentas);
            }
        }while(!"4".equals(obtenerEntrada));
    }

    // Metodo que muestra el listado de las golosinas
    public static void mostrarGolosinas(){
        System.out.println("Listado de productos...");
        for (int i = 0; i < nombresGolosinas.length; i++) {        // El primer índice recorre las filas.
            for (int j = 0; j < nombresGolosinas[i].length; j++) {    // El segundo índice recorre las columnas.
                // Procesamos cada elemento de la matriz.
                System.out.println("\nCódigo: " + i + j + "\nProducto: " + nombresGolosinas[i][j] + "\nPrecio: " + precio[i][j] + "\n"+"Cantidad: "+cantidad[i][j]);
            }
        }
    }

    //Metodo para pedir golosinas
    public static void pedirGolosina(){
        System.out.println("Indique el número de la golosina que desea: ");
        String posicion = "";
        Scanner obtenerScanner = new Scanner(System.in); // Creamos el objeto scanner
        posicion = obtenerScanner.nextLine();
        char[] digits = posicion.toCharArray();
        int fila = Character.getNumericValue(digits[0]);
        int columna = Character.getNumericValue(digits[1]);

        cantidad[fila][columna] = cantidad[fila][columna] - 1;
        if(cantidad[fila][columna]  < 0){
            System.out.println("No hay más: "+ nombresGolosinas[fila][columna]);
        }else{
            System.out.println("Usted ha realizado la compra de: "+ nombresGolosinas[fila][columna]);
        }

    }

    // Metodo para llenar el inventario
    public static void rellenarInventario(){
        String passUser = "MaquinaExpendedora2022";
        String codigoProducto = "";
        String cantidadProducto = "";
        String entradaPassword = "";
        System.out.println("Introduzca la contraseña para continuar:");
        Scanner obtenerScanner1 = new Scanner(System.in); // Creamos el objeto scanner
        entradaPassword = obtenerScanner1.next();

        if(passUser.equals(entradaPassword)){
            System.out.println("Hola Bayron, bienvenido al sistema de inventario. \n Introduce el código del producto que deseas agregar:");
            Scanner obtenerScanner2 = new Scanner(System.in);
            codigoProducto = obtenerScanner2.nextLine();

            char[] digito = codigoProducto.toCharArray();
            int fila1 = Character.getNumericValue(digito[0]);
            int columna1 = Character.getNumericValue(digito[1]);

            System.out.println("Introduce la cantidad del producto: "+ nombresGolosinas[fila1][columna1]);
            cantidadProducto = obtenerScanner2.nextLine();

            int total = Integer.parseInt(cantidadProducto);
            if(total > 9){
                System.out.println("La cantidad insertada no está permitida.");
            }else{
                cantidad[fila1][columna1] = cantidad[fila1][columna1] + total;
                System.out.println("Se ha agregado su producto correctamente.");
            }

        }else{
            System.out.println("La contraseña no es correcta, por favor intentalo de nuevo.");
        }
    }
}
