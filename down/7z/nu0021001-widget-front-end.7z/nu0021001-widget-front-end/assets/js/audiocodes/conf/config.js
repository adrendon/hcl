let c2c_serverConfig = {
    domain: '',                 // SBC domain name, used to build SIP headers From/To
    addresses: '',  // AudioCodes SBC secure web socket address (can be multiple)
    // addresses: '_take_value_from_url_', // Special case. Get SBC address from URL 'server' parameter.
    iceServers: [],                        // Optional STUN or TURN servers. Don't set TURN server password here. It's unsecure !  
    /* Optional TURN server 
       iceServers: [
           { urls: 'turn:example.turn.com',
             //username: 'xxx',     Note: username and credential is better set not here but in c2c.js code 
             //credential: 'yyy',
           }
        ],
        iceTransportPolicyRelay: false      // Optional. For TURN server debugging. If true will be used only 'relay' ice candidate
    */

    /*
     // Optional websocket logger server (instead console.log)
     logger: 'example.com/wslog'
    */
};

let c2c_config = {
    // Call
    call: '', // Call to this user name (or phone number). Special value: '_take_value_from_url_' to set the value from URL 'call' parameter
    caller: '', // Caller user name (One word according SIP RFC 3261). 
    callerDN: '', // Caller display name (words sequence).
    type: 'user_control',   // Call type: 'audio', 'video' or 'user_control'
    videoCheckboxDefault: false, // For 'user_control' call, default value of video checkbox.
    //videoSize: { width: '400px', height: '300px' }, // video size (a little smaller)
    videoSize: { width: '480px', height: '360px' }, // video size (a little bigger)
    callAutoStart: 'no',  // Start call automatically after page loading. Values: 'yes' (start if autoplay policy enabled) 'yes force' (start always), 'no' (don't start call automatically)                                      
    messageDisplayTime: 5, // A message will be displayed during this time (seconds).
    restoreCallMaxDelay: 20, // After page reloading, call can be restored within the time interval (seconds).
    allowCallWithoutMicrophone: true, // Allow call even without microphone, if microphone is missed send sound: "absenceMicrophoneSound" 
    networkPriority: undefined, // Sending RTP DSCP network priority: undefined (don't change) or 'high', 'medium', 'low', 'very-low'. Supported only in Chrome.
    urlToken: false,             // Optional. Experimental. Take security token from URI and send it as special SIP header.

    // Optional test call to check line quality.
    testCallEnabled: true,    // If test call enabled (show test call GUI)
    testCallSBCScore: true,   // Test call voice quality score calculated by SBC API (true) or browser API (false).
    testCallUser: '5555',     // Call to this user for test call (It's special test call user in SBC that auto answer and play sound prompt)
    testCallAutoStart: false,  // Start test call automatically after page loading when auto play policy enable play sound or when for test call used microphone.
    testCallUseMicrophone: false, // Send microphone sound (true) or generated tone/download sound (false).
    testCallVolume: 0.0,     // 1.0 .. 0.0. Hear or not test call audio prompt received from SBC
    testCallMinDuration: 10,  // For SBC API request URL "duration" value (converted to ms), for browser API minimum test duration value.
    testCallMaxDuration: 20,  // For browser API only. Call will terminated after testCallMinDuration if received remote-inbound-rtp and always after testCallMaxDuration.
    testCallQualityText: {    // For SBC API only. mapping SBC "color" voice quality score with corresponding text message.
        'green': 'Good', 'yellow': 'Fair', 'red': 'Low', 'gray': 'N/A'
    },

    // Websocket keep alive.
    pingInterval: 10,          // Keep alive ping interval,  0 value means don't send pings. (seconds)
    pongTimeout: true,         // Close and reopen websocket when pong timeout detected
    timerThrottlingBestEffort: true, // Action if timer throttling detected (for Chrome increase ping interval)
    pongReport: 60,       // if 0 not print, otherwise each N pongs print min and max pong delay 
    pongDist: false,      // Print to console log also pong delay distribution.    

    // SDK modes. 
    modes: {
        ice_timeout_fix: 2000,             // ICE gathering timeout (milliseconds)
        chrome_rtp_timeout_fix: 13,        // Workaround of https://bugs.chromium.org/p/chromium/issues/detail?id=982793
    }
};

const audioPlayerConfig = new AudioPlayer();
const dtmfTones = audioPlayerConfig.dtmfTones;

let c2c_soundConfig = {
    generateTones: {
        // Phone ringing, busy and other tones vary in different countries.
        // Please see: https://www.itu.int/ITU-T/inr/forms/files/tones-0203.pdf
        ringingTone: [{ f: 400, t: 1.5 }, { t: 3.5 }],
        busyTone: [{ f: 400, t: 0.5 }, { t: 0.5 }],
        disconnectTone: [{ f: 400, t: 0.5 }, { t: 0.5 }],
        // tones sequence for test call and absence microphone call. 
        sirenTone: [{ f: 400, t: 1.0 }, { f: 300, t: 0.5 }],
        noMicTone: [{ f: 2200, t: 0.1 }, { t: 0.06 }, { f: 2500, t: 0.1 }, { t: 4.0 }],
        zeroTone: dtmfTones['0'],
        oneTone: dtmfTones['1'],
        twoTone: dtmfTones['2'],
        threeTone: dtmfTones['3'],
        fourTone: dtmfTones['4'],
        fiveTone: dtmfTones['5'],
        sixTone: dtmfTones['6'],
        sevenTone: dtmfTones['7'],
        eightTone: dtmfTones['8'],
        nineTone: dtmfTones['9'],
        astericTone: dtmfTones['*'],
        numeralTone: dtmfTones['#']
    },
    downloadSounds: [
        // mp3 recorded sound can be used instead of tones sequence.
        // { flowingStream: 'flowing_stream' }
    ],
    play: {
        outgoingCallProgress: { name: 'ringingTone', loop: true, volume: 0.2 },
        busy: { name: 'busyTone', volume: 0.2, repeat: 4 },
        disconnect: { name: 'disconnectTone', volume: 0.2, repeat: 3 },
        testCallSound: { name: 'sirenTone', loop: true, volume: 1.0 },
        noMicrophoneSound: { name: 'noMicTone', loop: true, volume: 0.1 },
        "0": { name: 'zeroTone', volume: 0.25 },
        "1": { name: 'oneTone', volume: 0.25 },
        "2": { name: 'twoTone', volume: 0.25 },
        "3": { name: 'threeTone', volume: 0.25 },
        "4": { name: 'fourTone', volume: 0.25 },
        "5": { name: 'fiveTone', volume: 0.25 },
        "6": { name: 'sixTone', volume: 0.25 },
        "7": { name: 'sevenTone', volume: 0.25 },
        "8": { name: 'eightTone', volume: 0.25 },
        "9": {name: 'nineTone', volume: 0.25 },
        "*": { name: 'astericTone', volume: 0.25 },
        "#": { name: 'numeralTone', volume: 0.25 }
    },
};