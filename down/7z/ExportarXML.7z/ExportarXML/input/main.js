const fs = require('fs')
const path = require('path');

const db = require('../input/dbOPNuevo.json')
const directoryPath = path.join(__dirname, 'archivos');

//let nameFile = 'tendencias'

fs.readdir(directoryPath, function (err, files) {
    files.forEach(function (file) {
        // Do whatever you want to do with the file
        let nameFile = file.slice(0,-4);
        let fileinput = fs.readFileSync(`../input/archivos/${nameFile}.xml`, 'utf-8')
        for (const item in db) {
            let origen = new RegExp(db[item].Origen, 'g')
            let destino = db[item].Destino
            fileinput = fileinput.replace(origen, destino)
        }
        fs.writeFileSync(`../output/${nameFile}.xml`, `${fileinput}`, {flag: 'w'})
        console.log('Creado: '+ nameFile+'.xml')
    });
    console.log('Se creo un total de: '+ files.length+' archivos');
});
