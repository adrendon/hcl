const db = require('./db.json')
const fs = require('fs');

const dataFilter = (dataContent) => {
    dataContent.filter((v, i) => dataContent.indexOf(v) == i)
    dataContent.filter(function (value, index, arr) {
        return value !== "-9999";
    })
    return dataContent
}

const seach_db = (data) => {
    let string_data = JSON.stringify(data)
    let valor = []
    for (const dbKey in db) {
        let regex = new RegExp(db[dbKey].origen, 'g')
        if (string_data.search(regex) > 0) {
            valor.push(db[dbKey])
        }
    }
    return valor
}

const replace_db = (data,objReplace) => {
    let string_data = JSON.stringify(data)
    for (const objReplaceKey in objReplace) {
        let regex = new RegExp(objReplace[objReplaceKey].origen, 'g')
        string_data = string_data.replace(regex, objReplace[objReplaceKey].destino)
    }
    return string_data
}

const mkdir_fs = (path) => {
    if (!fs.existsSync(`${path}`)) {
        fs.mkdir(`${path}`, {recursive: true}, (err) => {
            if (err) throw err;
        });
    }
}

module.exports = {dataFilter, seach_db, replace_db, mkdir_fs}