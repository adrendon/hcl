const fs = require('fs');
const {dataFilter, seach_db, replace_db, mkdir_fs} = require('./src/config/modules')
const {configHeaders, configHeadersLocal, app_paths} = require('./src/config/config');
const {restGet, restPut} = require('./src/service/service_wcm');

(async () => {
    let urlBase = `${app_paths.urlWcm.hostDev}/caass?current=true&urile=wcm:path:negociosmigracion/ascaas/contIds&mime-type=application/json`
    let dataContent = dataFilter(await restGet(urlBase))
    //Lista de contenidos a modificar
    for (const dataContentKey in dataContent) {
        let pathWcmApi = app_paths.wcm_api.contructorUrl(app_paths.urlWcm.hostDev, false, dataContent[dataContentKey], app_paths.wcm_api.content, false)
        let data = await restGet(pathWcmApi, configHeaders);
        //Borramos el Id porque no se debe enviar esta propiedad para actualizar
        delete data.entry.id;
        //Buscamos si realmente debemos modificar algo o no en el contenido
        let db_replace = seach_db(data)
        if (db_replace.length > 0) {
            //Creando el Backup de la data
            let backFolder = `${app_paths.logs.mkLog}201/${dataContent[dataContentKey]}`
            mkdir_fs(backFolder)
            fs.writeFileSync(`${backFolder}/Org_${dataContent[dataContentKey]}.json`, JSON.stringify(data), {flag: 'w'})
            //Cambio segun el archivo db.json
            let dataChange = replace_db(data, db_replace)
            fs.writeFileSync(`${backFolder}/Mod_${dataContent[dataContentKey]}.json`, JSON.stringify(JSON.parse(dataChange)), {flag: 'w'})
            let {href} = data.entry.link.find(url => url.rel === 'edit')
            let uriWcm = app_paths.urlWcm.hostDev + href + app_paths.wcm_api.minitype
            //Llamado el Put de Api del portal
            await restPut(uriWcm, JSON.parse(dataChange), configHeaders)
            console.log(`Cambio realizado para el contenido ${dataContent[dataContentKey]} #${dataContentKey} de ${dataContent.length}`)
        } else {
            console.log(`Sin cambio para el contenido ${dataContent[dataContentKey]} #${dataContentKey} de ${dataContent.length}`)
        }
    }
    console.log('listo', dataContent)
})()
