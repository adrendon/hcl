package formpymes.api.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import formpymes.api.util.validadores.InyeccionSQL;



/**
 * DTO para el transporte de datos a la vista, con la informaci�n general de la transacci�n
 * @author shidalgo - Sergio Hidalgo - IBM
 * @since 11/5/2017
 */
@XmlRootElement
public class FormpymesDTO implements Serializable {
	
	private static final long serialVersionUID = 578496614712459333L;

	
	@InyeccionSQL(message = "Intento de inyecci�n SQL en el campo id")
	@Size(min = 1, max = 15, message = "id no cumple con la longitud m�nima (1) y/o m�xima (15)")
	private String nit;


	@InyeccionSQL(message = "Intento de inyecci�n SQL en el campo id")
	@Size(min = 1, max = 100, message = "nombreEmp no cumple con la longitud m�nima (1) y/o m�xima (100)")
	private String nombreEmp;
	

	@InyeccionSQL(message = "Intento de inyecci�n SQL en el campo id")
	@Size(min = 1, max = 80, message = "id no cumple con la longitud m�nima (1) y/o m�xima (100)")
	private String correo;


	private List<String> suscripcion;
	
	@InyeccionSQL(message = "Intento de inyecci�n SQL en el campo nombreSus")
	@Size(min = 1, max = 50, message = "NombreSus no cumple con la longitud maximo (1) y/o max�ma (50)")
	private String nombreSus;
	
//	@InyeccionSQL(message = "Intento de inyecci�n SQL en el campo apellidoSus")
//	@Size(min = 1, max = 25, message = "ApellidoS no cumple con la longitud m�nima (1) y/o m�xima (25)")
//	private String apellidoSus;	

	@InyeccionSQL(message = "Intento de inyecci�n SQL en el campo id")
	@Size(min = 1, max = 5, message = "id no cumple con la longitud m�nima (1) y/o m�xima (100)")
	private String confirmacion;


	public String getNit() {
		return nit;
	}


	public void setNit(String nit) {
		this.nit = nit;
	}


	public String getNombreEmp() {
		return nombreEmp;
	}


	public void setNombreEmp(String nombreEmp) {
		this.nombreEmp = nombreEmp;
	}


	public String getCorreo() {
		return correo;
	}


	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public List<String> getSuscripcion() {
		return suscripcion;
	}


	public void setSuscripcion(List<String> suscripcion) {
		this.suscripcion = suscripcion;
	}


	public String getConfirmacion() {
		return confirmacion;
	}


	public void setConfirmacion(String confirmacion) {
		this.confirmacion = confirmacion;
	}

	String Fecha;
	
	String SuscripcionString;


public String getFecha() {
		return Fecha;
	}


	public void setFecha(String fecha) {
		Fecha = fecha;
	}


public String getSuscripcionString() {
	return SuscripcionString;
}


public void setSuscripcionString(String suscripcionString) {
	SuscripcionString = suscripcionString;
}

	
/**
 * @return the nombreSus
 */
public String getNombreSus() {
    return nombreSus;
}


/**
 * @param nombreSus the nombreSus to set
 */
public void setNombreSus(String nombreSus) {
    this.nombreSus = nombreSus;
}


/**
 * @return the apellidoSus
 */
//public String getApellidoSus() {
//    return apellidoSus;
//}
//
//
///**
// * @param apellidoSus the apellidoSus to set
// */
//public void setApellidoSus(String apellidoSus) {
//    this.apellidoSus = apellidoSus;
//}
	
	
}



