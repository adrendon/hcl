package formpymes.api.controllers;

import java.io.Serializable;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import formpymes.api.dto.FormpymesDTO;
import formpymes.api.ejb.IFormpymesServiceLocal;
import formpymes.api.services.FormPymesServiceException;

/**
 * Controlador para el manejo de servicios
 */
@Stateless(mappedName = "FormpymesController")
@Path("servicio")
public class FormpymesController implements Serializable {

	/**serialVersionUID**/
	private static final long serialVersionUID = 9220923610431177312L;
	private static final String ENCODING = "UTF-8";
	
	
	@EJB
	private IFormpymesServiceLocal service;
	

	@POST
	@Path("/regitrarSuscripcion")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON + ";charset=" + ENCODING)
	public Response regitrarSuscripcion(FormpymesDTO dto) {

		try {
			//Json recibido del cliente
			service.regitrarSuscripcion(dto);			
			//String respuesta= "";
			service.enviarCorreo (dto);			
			return Response.status(Response.Status.OK).entity(new String("Registro exitoso")).build();			
		} catch (FormPymesServiceException e) {			
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}	
	}
	
	@GET
	@Path("/InformeRegistrosPymes")
	@Produces(MediaType.APPLICATION_JSON + ";charse=" + ENCODING)
	public Response reporteEventoSaberes() {
		try {
			//Envia el correo cada semana
			service.GenerarReportePymes ();
			return Response.status(Response.Status.OK).entity(new String("Reporte generado exitosamente")).build();
		} catch(FormPymesServiceException e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}
	

	/**
	 * Transforma una clase a un objeto json
	 * @param objeto
	 * @return
	 */
	public static String parseJson(Object objeto){
		return new Gson().toJson(objeto);
	}

}
