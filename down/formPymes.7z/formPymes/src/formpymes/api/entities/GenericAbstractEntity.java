package formpymes.api.entities;

import java.io.Serializable;

/**
 * Clase Base para el manejo de entidades
 * @author shidalgo
 * @since 11/11/2017
 */
public abstract class GenericAbstractEntity implements Serializable {

	/**serialVersionUID**/
	private static final long serialVersionUID = -6487214592913379039L;
	
}
