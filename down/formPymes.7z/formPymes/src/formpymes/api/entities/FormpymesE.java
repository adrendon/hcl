package formpymes.api.entities;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/**
 * Entidad que representa la información de contacto
 * @author shidalgo
 * @since 11/11/2017
 */
@Entity
@Table(name = "FORMPYMES")
public class FormpymesE extends GenericAbstractEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1928853241811336687L;

	/** Correo */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "IdForpymes")
	protected int idFormpymes;

	/** nit */
	@Column(name = "Nit")
	@Size(max = 20)
	protected String nit;

	/** Nombre */
	@Column(name = "Nombre")
	@Size(max = 50)
	protected String nombre;
	
	/** Nombre Suscriptor  */
	@Column(name = "NombreSus")
	@Size(max = 50)
	protected String nombreSus;

//	/** Apellido Suscriptor  */
//	@Column(name = "ApellidoSus")
//	@Size(max = 25)
//	protected String apellidoSus;
	
	/** correo electronico */
	@Column(name = "Correo")
	@Size(max = 50)
	protected String correo;

	/** Categorias de suscripcion */
	@Column(name = "Suscripciones")
	@Size(max = 200)
	protected String suscripciones;


	/** Check donde Acepta Terminos y Condiciones del formulario */
	@Column(name = "Confirma")
	protected int confirma=1;
	
	/** Fecha y hora de creacion del registro */
	@Column(name = "Fecha")
	@Temporal(TemporalType.TIMESTAMP)
	protected Date fechacreate;

	public int getIdFormpymes() {
		return idFormpymes;
	}

	public void setIdFormpymes(int idFormpymes) {
		this.idFormpymes = idFormpymes;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getSuscripciones() {
		return suscripciones;
	}

	public void setSuscripciones(String suscripciones) {
		this.suscripciones = suscripciones;
	}

	public int getConfirma() {
		return confirma;
	}

	public void setConfirma(int confirma) {
		this.confirma = confirma;
	}

	public Date getFechacreate() {
		return fechacreate;
	}

	public void setFechacreate(Date fechacreate) {
		this.fechacreate = fechacreate;
	}

	/**
	 * @return the nombreSus
	 */
	public String getNombreSus() {
	    return nombreSus;
	}

	/**
	 * @param nombreSus the nombreSus to set
	 */
	public void setNombreSus(String nombreSus) {
	    this.nombreSus = nombreSus;
	}

	/**
	 * @return the apellidoSus
	 */
//	public String getApellidoSus() {
//	    return apellidoSus;
//	}
//
//	/**
//	 * @param apellidoSus the apellidoSus to set
//	 */
//	public void setApellidoSus(String apellidoSus) {
//	    this.apellidoSus = apellidoSus;
//	}

	

}
