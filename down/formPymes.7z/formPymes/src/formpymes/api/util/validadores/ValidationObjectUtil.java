package formpymes.api.util.validadores;

import java.io.Serializable;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

/**
 * Singleton para validar objetos
 * @author juancard - Juan Carlos Cardona - IBM
 * @since 31/3/2017
 */
public class ValidationObjectUtil implements Serializable {

	/**serialVersionUID**/
	private static final long serialVersionUID = -6993835486199334640L;

	private static ValidationObjectUtil instance = null;
	private ValidatorFactory factory = null;
	private Validator validator = null;
	
	/**
	 * Constructor privado por singleton
	 */
	private ValidationObjectUtil() {
		factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
	}

	/**
	 * Obtiene una instancia �nica del singleton
	 */
	public static ValidationObjectUtil getInstance(){
		if(instance==null){
			instance = new ValidationObjectUtil();
		}
		return instance;
	}
	
	/**
	 * Valida los diferentes validator como {@link InyeccionSQL}
	 * @param objeto
	 * @throws ValidationObjectException excepci�n generada por la validaci�n
	 */
	public void validate(Object objeto) throws ValidationObjectException {
		if(objeto!=null){
			Set<ConstraintViolation<Object>> violations = validator.validate(objeto);
			if (!violations.isEmpty()) {
				String errorMsj = "Error validando objeto" + objeto.getClass().getName() + "valor" +  objeto.toString() + "detalles: ";
				for (ConstraintViolation<Object> violation : violations) {
					errorMsj += violation.getMessage() + ", ";
				}
				throw new ValidationObjectException(errorMsj);
			}
		}
	}
	
}
