package formpymes.api.util.validadores;

/**
 * Excepcion para validaciones generales
 * @author juancard - Juan Carlos Cardona - IBM
 * @since 31/3/2017
 */
public class ValidationObjectException extends Exception {

	/**serialVersionUID**/
	private static final long serialVersionUID = -7498416372916883158L;

	/**
	 * 
	 */
	public ValidationObjectException() {
		super();
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ValidationObjectException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public ValidationObjectException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public ValidationObjectException(Throwable cause) {
		super(cause);
	}

	
	
	
}
