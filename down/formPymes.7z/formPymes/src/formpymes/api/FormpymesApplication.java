package formpymes.api;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import formpymes.api.comun.JsonProvider;
import formpymes.api.comun.OutputStreamProvider;
import formpymes.api.controllers.FormpymesController;

/**
 * Clase principal de la aplicación
 * @author shidalgo
 * @since 26/4/2017
 */
public class FormpymesApplication extends Application {

	@Override
	public Set<Class<?>> getClasses() {
		
		Set<Class<?>> classes = new HashSet<Class<?>>();
		
		//Providers  
		classes.add(JsonProvider.class);
		classes.add(OutputStreamProvider.class);
		
		//Recursos
		classes.add(FormpymesController.class);
		
		return classes;
	}

}
