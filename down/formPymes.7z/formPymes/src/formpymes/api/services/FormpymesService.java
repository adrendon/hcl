package formpymes.api.services;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Status;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;

import co.bancolombia.ree.lib.Config;
import fase3.comunes.excel.ConstructorExcel;
import fase3.comunes.excel.ItemExportacionExcel;
import fase3.comunes.excel.TipoDatoExcel;
import fase3.email.EnviarEmailIBM;
import formpymes.api.dto.FormpymesDTO;
import formpymes.api.ejb.IFormpymesServiceLocal;
import formpymes.api.entities.FormpymesE;
import formpymes.api.util.validadores.ValidationObjectException;
import formpymes.api.util.validadores.ValidationObjectUtil;

/**
 * Servicio con la responsabilidad exponer los diferentes serviciosn para la
 * venda digital de Préstamos Personales
 */
@Stateless(mappedName = "FormpymesService")
@Local(IFormpymesServiceLocal.class)
@TransactionManagement(TransactionManagementType.BEAN)
public class FormpymesService implements IFormpymesServiceLocal {

	private Logger logger = Logger.getLogger(this.getClass());
	
	private static final String UNIDAD_PERSISTENCIA = "CONTAC";

	/** Manager de entidades **/
	@PersistenceContext(unitName = UNIDAD_PERSISTENCIA)
	private EntityManager em = null;

	/** Transacción **/
	@Resource
	private UserTransaction userTransaction = null;

	/** Constructor **/
	public FormpymesService() {
		super();
	}

	@Override
	public void regitrarSuscripcion(FormpymesDTO dto)
			throws FormPymesServiceException {

		try {
			validarObjetoEntrada(dto);

			FormpymesE formpyE = new FormpymesE();

			formpyE.setNit(dto.getNit());
			formpyE.setNombre(dto.getNombreEmp());
			formpyE.setNombreSus(dto.getNombreSus());
//			formpyE.setApellidoSus(dto.getApellidoSus());
			formpyE.setCorreo(dto.getCorreo());
			formpyE.setFechacreate(new Date());
			formpyE.setSuscripciones(parseCategorias(dto.getSuscripcion()));

			userTransaction.begin();
			em.merge(formpyE);
			userTransaction.commit();
		} catch (Exception e) {
			try {
				if(userTransaction.getStatus() == Status.STATUS_ACTIVE) {
					userTransaction.rollback();
				}
			} catch(SystemException e1) {
				throw new FormPymesServiceException(e1);
			}
			throw new FormPymesServiceException("Error registrando en base de datos", e);
		}		
	}

	private String parseCategorias(List<String> suscripcion) {
		String parse = "";
		for (String value : suscripcion) {
			parse += value + ",";
		}
		parse = parse.substring(0, parse.length() - 1);
		return parse;
	}

	/**
	 * Valida un objeto {@link TarjetaCreditoVD}
	 * 
	 * @param transaccionPP
	 * @throws ValidationObjectException
	 */
	private void validarObjetoEntrada(Object object)
			throws ValidationObjectException {
		ValidationObjectUtil.getInstance().validate(object);
	}

	private InitialContext initContext = null;
	private Config config = null;

	public void enviarCorreo(FormpymesDTO formpymesDTO) throws FormPymesServiceException{
		try {

			initContext = new InitialContext();
			config = (Config) initContext.lookup("prop/parametrosFPy");

			// se obtienen los parametros de invocacion al servicio
			String estadoServicio = config.getAttribute("estadoServicio")
					.toString();

			if (estadoServicio.equals("Y")) {
				Map<String, String> configuracion = new HashMap<String, String>();
				Map<String, String> datosMail = new HashMap<String, String>();
				Map<String, String> adjuntosMail = new HashMap<String, String>();
				Map<String, String> adjuntosImagenes = new HashMap<String, String>();

				configuracion.put("RUTA_MAIL_PLANTILLA",
						config.getAttribute("rutaPlantilla").toString());
				configuracion.put("MAIL_SENDGRID_USER",
						config.getAttribute("sendGridUser").toString());
				configuracion.put("MAIL_SENDGRID_PASSWORD", config
						.getAttribute("sendGridPass").toString());

				datosMail.put("REMITENTE_MAIL", config
						.getAttribute("remitente").toString());
				datosMail.put("ASUNTO_MAIL", config.getAttribute("asunto")
						.toString());

				String correodest = formpymesDTO.getCorreo()
						+ config.getAttribute("SuscPymes.para").toString();

				datosMail.put("DESTINO_MAIL", correodest);
				datosMail.put("NOMBRE", formpymesDTO.getNombreSus());
//				datosMail.put("APELLIDO", formpymesDTO.getApellidoSus());
				
				List<String> suscripcion = formpymesDTO.getSuscripcion();
				Integer sizeSus = suscripcion.size();
				Integer totalTopics = 10;
				for (int i = 0; i < totalTopics; i++) {
					if(i < sizeSus) {
						datosMail.put("TEMA"+ i, suscripcion.get(i));
					} else {
						/*Define si se muestra o no en la plantilla de correo*/
						datosMail.put("TEMA" + i, "none"); 
					}
					
				}				

				adjuntosImagenes.put("idBanner", config.getAttribute("rutaImg")
						.toString() + "fotobanner.jpg");
				adjuntosImagenes.put("idVigilado",
						config.getAttribute("rutaImg").toString()
								+ "vigilado.png");
				adjuntosImagenes.put("idLogoPymes", config.getAttribute("rutaImg").toString() + "logopyme.png");

				EnviarEmailIBM.enviarEmailIBM("Email_FormPymes", configuracion,
						datosMail, adjuntosMail, adjuntosImagenes);
			} else {
				throw new FormPymesServiceException("Estado del servicio envio email inactivo");
			}
		} catch (Exception e) {
			throw new FormPymesServiceException("Error en el envío del email - Leyendo configuración de WAS", e);
		}

	}

	private ArrayList<ItemExportacionExcel> definiciones;

	@Override
	@SuppressWarnings({ "rawtypes" })
	public void GenerarReportePymes() throws FormPymesServiceException {

		Query query = em.createQuery("SELECT a FROM FormpymesE a WHERE fecha BETWEEN '2019-01-01 00:00:00' AND '2019-12-31 23:59:00' ORDER BY FECHA");
		List<FormpymesE> resultadoPymes = query.getResultList();

		try {
			definiciones = new ArrayList<>();
			definiciones.add(new ItemExportacionExcel("nit", 0, "NIT",
					TipoDatoExcel.STRING, 20));
			definiciones.add(new ItemExportacionExcel("nombreEmp", 1, "NOMBRE EMPRESA",
					TipoDatoExcel.STRING, 30));
			definiciones.add(new ItemExportacionExcel("nombreSus", 2, "NOMBRE",
				TipoDatoExcel.STRING, 50));
			definiciones.add(new ItemExportacionExcel("correo", 3, "CORREO",
					TipoDatoExcel.STRING, 30));
			definiciones.add(new ItemExportacionExcel("SuscripcionString", 4,
					"SUSCRIPCIONES", TipoDatoExcel.STRING, 200));
			definiciones.add(new ItemExportacionExcel("confirmacion", 5,
					"CONFIRMA", TipoDatoExcel.STRING, 15));
			definiciones.add(new ItemExportacionExcel("Fecha", 6, "FECHA",
					TipoDatoExcel.STRING, 30));

			String StrfechaArchivo = new SimpleDateFormat("dd-MM-yyyy")
					.format(new Date());
			String nombre_archivo = "ReporteContactosPymes_" + StrfechaArchivo;

			ArrayList<FormpymesDTO> data = new ArrayList<>();
			ConstructorExcel<FormpymesDTO> constructorExcel;

			// int numero_lineas = 0;

			// organizo la data para enviar a construir el reporte en excel

			for (Iterator iterator = resultadoPymes.iterator(); iterator
					.hasNext();) {
				// numero_lineas++;

				FormpymesE temp = (FormpymesE) iterator.next();

				FormpymesDTO FormpymesDTO = new FormpymesDTO();

				FormpymesDTO.setNit(temp.getNit());
				FormpymesDTO.setNombreEmp(temp.getNombre());
				FormpymesDTO.setNombreSus(temp.getNombreSus());
//				FormpymesDTO.setApellidoSus(temp.getApellidoSus());
				FormpymesDTO.setCorreo(temp.getCorreo());
				FormpymesDTO.setSuscripcionString(temp.getSuscripciones());
				FormpymesDTO.setFecha(temp.getFechacreate().toString());
				FormpymesDTO.setConfirmacion(temp.getConfirma() + "");				

				data.add(FormpymesDTO);
			}

			initContext = new InitialContext();
			config = (Config) initContext.lookup("prop/parametrosFPy");

			constructorExcel = new ConstructorExcel<FormpymesDTO>(definiciones,
					config.getAttribute("RutaGeneracionExcel").toString(),
					nombre_archivo, data);
			File rep_excel = constructorExcel
					.exportarFormatoExcel("Reporte Contacto Pymes");

			logger.info("generó el archivo" + rep_excel.getAbsolutePath());

			// Configuracion para envio de correo con el adjunto
			Map<String, String> configuracion = new HashMap<String, String>();
			Map<String, String> datosMail = new HashMap<String, String>();
			Map<String, String> adjuntosMail = new HashMap<String, String>();
			Map<String, String> adjuntosImagenes = new HashMap<String, String>();

			configuracion.put("RUTA_MAIL_PLANTILLA",
					config.getAttribute("rutaPlantilla").toString());
			configuracion.put("MAIL_SENDGRID_USER",
					config.getAttribute("sendGridUser").toString());
			configuracion.put("MAIL_SENDGRID_PASSWORD",
					config.getAttribute("sendGridPass").toString());

			datosMail.put("REMITENTE_MAIL", config.getAttribute("remitente")
					.toString());
			datosMail.put("ASUNTO_MAIL", config.getAttribute("asunto")
					.toString());
			datosMail.put("DESTINO_MAIL", config
					.getAttribute("ReportePymePara").toString());

			String ruta = config.getAttribute("RutaGeneracionExcel").toString();
			String rutafull = ruta + "/" + nombre_archivo + ".xls";
			adjuntosMail.put("ReporteContactoPymes", rutafull);			

			EnviarEmailIBM.enviarEmailIBM("Email-InformePymes", configuracion,
					datosMail, adjuntosMail, adjuntosImagenes);			
		} catch (Exception e) {
			throw new FormPymesServiceException("Error generando o enviando el reporte", e);			
		}
	}

}// fin class service
