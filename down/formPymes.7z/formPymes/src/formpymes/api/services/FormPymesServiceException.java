/**
 * 
 */
package formpymes.api.services;

import org.apache.log4j.Logger;

/**
 * Clase para manejo de excepciones propias
 * IBM Global Business Services GBS Colombia
 * @author andressanchez - Andres Ceballos Sanchez - andres.sanchez@ibm.com
 * @since 12/02/2018
 * @version 1.0
 *
 */
public class FormPymesServiceException extends Exception {

	/**serialVersionUID**/
	private static final long serialVersionUID = 6750066968711308466L;

	private Logger logger = Logger.getLogger(this.getClass());
	
	
	public FormPymesServiceException() {
		super();
	}

	/**
	 * @param message
	 */
	public FormPymesServiceException(String message) {
		super(message);
		logger.error(message);
	}

	/**
	 * @param cause
	 */
	public FormPymesServiceException(Throwable cause) {
		super(cause);
		logger.error(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public FormPymesServiceException(String message, Throwable cause) {
		super(message, cause);
		logger.error(message, cause);
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public FormPymesServiceException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
