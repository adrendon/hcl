package formpymes.api.ejb;

import java.util.List;

import formpymes.api.dto.FormpymesDTO;
import formpymes.api.services.FormPymesServiceException;


public interface IFormpymesServiceLocal {
	
	public void regitrarSuscripcion(FormpymesDTO dto) throws FormPymesServiceException;
	void enviarCorreo(FormpymesDTO dto) throws FormPymesServiceException;
	void GenerarReportePymes() throws FormPymesServiceException;

}
